import React from 'react'

export const AuthLayout = () => {
  return (
    <div>AuthLayout</div>
  )
}
