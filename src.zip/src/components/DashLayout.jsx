import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { Box, Button, CssBaseline } from '@mui/material';

const sidebarWidth = 190;
const navbarHeight = 64; // px

function DashLayout() {
  const location = useLocation();

  return (
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />

      {/* Sidebar */}
      <Box
        sx={{
          width: sidebarWidth,
          backgroundColor: '#000',
          flexShrink: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          padding: 2,
          pt: 10,
          height: '100vh',
          position: 'fixed',
          top: navbarHeight, // Positioned below navbar
          left: 0,
        }}
      >
        {['/dashboard', '/dashboard/reports', '/dashboard/users'].map((path) => (
          <Button
            key={path}
            fullWidth
            component={Link}
            to={path}
            variant={location.pathname === path ? 'contained' : 'outlined'}
            sx={{
              mb: 2,
              color: 'white',
              borderColor: 'white',
            }}
          >
            {path.split('/').pop()}
          </Button>
        ))}
      </Box>

      {/* Main Content */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          ml: `${sidebarWidth}px`,
          mt: `${navbarHeight}px`,
          p: 3,
          width: `calc(100% - ${sidebarWidth}px)`,
        }}
      >
        <Outlet />
      </Box>
    </Box>
  );
}

export default DashLayout;