import { Link, useNavigate } from 'react-router-dom';
import '../styles/Navbar.css';
import { useState } from 'react';
import logo from '../assets/luis-logo.png';

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    // Add your logout logic here if needed
    navigate('/');
  };

  return (
    <nav className="navbar" style={{ backgroundColor: '#000', color: '#fff' }}>
      <div className="navbar-container">
        <div className="logo">
          <Link to="/">
            <img src={logo} alt="Luis Logo" className="logo-img" />
          </Link>
        </div>

        <div className={`nav-links ${isOpen ? 'active' : ''}`}>
          <div className="nav-menu">
            <ul onClick={() => setIsOpen(false)}>
              <li><Link to="/home" style={{ color: '#fff' }}>Home</Link></li>
              <li><Link to="/dashboard" style={{ color: '#fff' }}>Dashboard</Link></li>
              <li><Link to="/articles" style={{ color: '#fff' }}>Article</Link></li>
              <li><Link to="/about" style={{ color: '#fff' }}>About</Link></li>
              <li><Link to="/contact" style={{ color: '#fff' }}>Contact Us</Link></li>
            </ul>
          </div>
          <button
            className="login-btn"
            onClick={handleLogout}
            style={{
              backgroundColor: '#fff',
              color: '#000',
              border: 'none',
              padding: '8px 16px',
              borderRadius: '4px',
              cursor: 'pointer',
            }}
          >
            Logout
          </button>
        </div>

        <div className="hamburger" onClick={() => setIsOpen(!isOpen)}>
          <span className={isOpen ? 'open' : ''}></span>
          <span className={isOpen ? 'open' : ''}></span>
          <span className={isOpen ? 'open' : ''}></span>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;