import React from 'react';
import { Typography, Grid, Paper, Box } from '@mui/material';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Jan', signups: 50 },
  { name: 'Feb', signups: 65 },
  { name: 'Mar', signups: 55 },
  { name: 'Apr', signups: 70 },
  { name: 'May', signups: 90 },
];

function DashboardPage() {
  return (
    <Box sx={{ backgroundColor: '#f0f2f5', minHeight: '100vh', p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', mb: 3 }}>
        Dashboard Overview
      </Typography>

      <Grid container spacing={2}>
        {[{ label: 'Total Users', value: 120 }, { label: 'Reports', value: 15 }, { label: 'Active Sessions', value: 8 }].map((item, index) => (
          <Grid item xs={12} sm={6} md={4} key={index}>
            <Paper
              elevation={2}
              sx={{
                p: 2,
                textAlign: 'center',
                backgroundColor: '#fff',
                borderRadius: 2,
                boxShadow: '0 3px 8px rgba(0,0,0,0.1)',
              }}
            >
              <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
                {item.value}
              </Typography>
              <Typography variant="subtitle2" color="textSecondary">
                {item.label}
              </Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Paper
        elevation={2}
        sx={{
          p: 3,
          mt: 3,
          backgroundColor: '#fff',
          borderRadius: 2,
          boxShadow: '0 3px 8px rgba(0,0,0,0.1)',
        }}
      >
        <Typography variant="h6" sx={{ fontWeight: 'bold', mb: 2 }}>
          Monthly Sign-ups
        </Typography>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={data} barCategoryGap="20%">
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="signups" fill="#1976d2" radius={[5, 5, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Paper>
    </Box>
  );
}

export default DashboardPage;