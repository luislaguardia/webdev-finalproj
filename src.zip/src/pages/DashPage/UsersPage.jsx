import React from 'react';
import { Typography, Paper, Box } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';

const columns = [
  { field: 'id', headerName: 'ID', width: 70 },
  { field: 'name', headerName: 'Name', width: 200 },
  { field: 'email', headerName: 'Email', width: 250 },
  { field: 'role', headerName: 'Role', width: 150 },
];

const rows = [
  { id: 1, name: 'Luis Laguardia', email: 'luis@gmail.com', role: 'Admin' },
  { id: 2, name: 'Yeyen Arellano', email: 'yen@gmail.com', role: 'User' },
  { id: 3, name: 'Jaja Colleen', email: 'colleen@gmail.com', role: 'User' },
  { id: 4, name: 'Rezelelee Enoc', email: 'rezelelee@gmail.com', role: 'User' },
];

function UsersPage() {
  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', mb: 3 }}>
        User Management
      </Typography>

      <Paper elevation={4} sx={{ p: 3 }}>
        <Typography variant="h6" sx={{ fontWeight: 'bold', mb: 2 }}>
          User List
        </Typography>
        <div style={{ height: 400, width: '100%' }}>
          <DataGrid
            rows={rows}
            columns={columns}
            pageSize={5}
            rowsPerPageOptions={[5, 10]}
            checkboxSelection
          />
        </div>
      </Paper>
    </Box>
  );
}

export default UsersPage;