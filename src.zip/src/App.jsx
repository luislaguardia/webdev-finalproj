import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import ArticleList from './pages/ArticleListPage';
import ArticlePage from './pages/ArticlePage';
import ContactPage from './pages/ContactPage';
import NotFoundPage from './pages/NotFoundPage';
import Footlong from './components/Footlong';
import LoginPage from './pages/LoginPage'; 
import RegistrationPage from './pages/RegistrationPage'; 
import WelcomePage from './pages/WelcomePage';  
import './styles/Layout.css';
// import { DashLayout } from './components/DashLayout';
// import { DashboardPage } from './pages/DashPage/DashboardPage';
// import DashboardPage from './pages/Dashboard Pages/DashboardPage';

// import DashboardPage from './pages/DashPage/DashboardPage';
import DashboardPage from './pages/DashPage/DashboardPage';
import ReportsPage from './pages/DashPage/ReportsPage';
import UsersPage from './pages/DashPage/UsersPage';
import DashLayout from './components/DashLayout';

function App() {
  return (
    <div className="app-container">
      <Router>
        <AppWithNavbar />
      </Router>
    </div>
  );
}

function AppWithNavbar() {
  const location = useLocation();

  const hideNavbarPaths = ['/', '/register', '/welcome']; // login page is now / (/login)

  return (
    <div>
      {!hideNavbarPaths.includes(location.pathname) && <Navbar />}
      
      <main>
        <Routes>
          <Route path="/" element={<LoginPage />} />
          <Route path="/home" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/articles" element={<ArticleList />} />
          <Route path="/articles/:id" element={<ArticlePage />} />
          <Route path="/contact" element={<ContactPage />} />
          
          {/* new routes for lab activity 5 */}
          {/* <Route path="/login" element={<LoginPage />} /> */}
          <Route path="/register" element={<RegistrationPage />} />
          <Route path="/welcome" element={<WelcomePage />} />

          {/* FOR DASHBOARD */}

                    <Route path="/dashboard/*" element={<DashLayout />}>
                      <Route index element={<DashboardPage />} />
                      <Route path="reports" element={<ReportsPage />} />
                      <Route path="users" element={<UsersPage />} />
                    </Route>


          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      
      <Footlong />
    </div>
  );
}

export default App;
